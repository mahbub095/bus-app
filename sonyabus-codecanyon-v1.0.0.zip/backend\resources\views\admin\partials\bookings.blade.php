<div class="admin-sections-layout" style="grid-column: 1 / -1;">

    <div class="admin-panel">
        <h3 class="admin-panel-title">
            Ticket Reservation Logs
            <span id="bookings-live-text" class="live-status" style="font-size: 11px;">
                <span class="live-dot"></span>
                Live disabled
            </span>
        </h3>

        {{-- Filter bar: search by PNR / contact + date range --}}
        <div class="log-filter-bar" style="display:flex; flex-wrap:wrap; gap:12px; align-items:flex-end; margin-bottom:16px; padding:12px 16px; background:rgba(99,102,241,0.05); border-radius:var(--border-radius-sm);">
            <div class="input-group" style="flex:1 1 260px; min-width:240px;">
                <label style="font-size:12px; font-weight:600; margin-bottom:4px;">Search (PNR / Contact)</label>
                <div style="position:relative;">
                    <input type="search" id="bookings-search" class="coupon-input"
                           style="height:38px; padding-right:34px;"
                           placeholder="SE00042 · 01712345678 · email · name"
                           autocomplete="off" spellcheck="false">
                    <button type="button" id="bookings-search-clear" title="Clear search"
                            style="position:absolute; right:8px; top:50%; transform:translateY(-50%);
                                   display:none; background:none; border:none; padding:2px 4px;
                                   color:var(--text-muted); font-size:17px; line-height:1; cursor:pointer;">
                        &times;
                    </button>
                </div>
            </div>
            <div class="input-group" style="flex:0 0 auto; min-width:170px;">
                <label style="font-size:12px; font-weight:600; margin-bottom:4px;">Date Filter</label>
                <select id="bookings-period" class="coupon-input" style="height:38px;">
                    <option value="all">All Records</option>
                    <option value="today">Today</option>
                    <option value="yesterday">Yesterday</option>
                    <option value="this_week">This Week</option>
                    <option value="this_month">This Month</option>
                    <option value="this_year">This Year</option>
                    <option value="custom">Custom Date Range</option>
                </select>
            </div>
            <div id="bookings-custom-dates" style="display:none; gap:12px; align-items:flex-end;">
                <div class="input-group" style="flex:0 0 auto; min-width:150px;">
                    <label style="font-size:12px; font-weight:600; margin-bottom:4px;">From Date</label>
                    <input type="date" id="bookings-from-date" class="coupon-input" style="height:38px;">
                </div>
                <div class="input-group" style="flex:0 0 auto; min-width:150px;">
                    <label style="font-size:12px; font-weight:600; margin-bottom:4px;">To Date</label>
                    <input type="date" id="bookings-to-date" class="coupon-input" style="height:38px;">
                </div>
            </div>
            <button type="button" id="bookings-apply-filter" class="btn btn-primary" style="height:38px; padding:0 18px;">Apply Filter</button>
            <button type="button" id="bookings-reset-filter" class="btn btn-secondary" style="height:38px; padding:0 16px;">Reset</button>
        </div>

        <div class="table-wrapper">
            <table class="admin-table" style="min-width: 900px;">
                <thead>
                    <tr>
                        <th>PNR Code</th>
                        <th>Passenger Name</th>
                        <th>Contact Information</th>
                        <th>Journey Details</th>
                        <th>Coach Reg. No.</th>
                        <th>Seats</th>
                        <th>Fare Paid</th>
                        <th>Status</th>
                        <th>Operations</th>
                    </tr>
                </thead>
                <tbody id="bookings-log-body">
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 30px; color: var(--text-muted)">
                            Open this tab to load live booking logs…
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        {{-- Pagination controls --}}
        <div class="bookings-pagination-bar" style="display:flex; gap:10px; align-items:center; margin-top:14px; flex-wrap:wrap;">
            <div class="input-group" style="flex:0 0 auto;">
                <label style="font-size:12px; font-weight:600; margin-bottom:4px;">Per page</label>
                <select id="bookings-per-page" class="coupon-input" style="height:38px;">
                    <option value="10" selected>10</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
            <span id="bookings-page-info" style="flex:0 0 auto; font-size:13px; color:var(--text-secondary);">Showing 0–0 of 0</span>
            <button id="bookings-prev-page" class="btn btn-secondary btn-sm" disabled>← Prev</button>
            <button id="bookings-next-page" class="btn btn-secondary btn-sm">Next →</button>
        </div>
    </div>

    <div class="booking-form-sidebar">
        <h3 class="booking-summary-title" id="booking-form-title">Create Booking</h3>
        <form class="booking-form-fields" id="booking-form" action="{{ route('admin.bookings.store') }}" method="POST">
            @csrf
            <input type="hidden" name="_method" id="booking-form-method" value="POST">
            <input type="hidden" name="_edit_id" value="">

            <div class="input-group" id="booking-schedule-group">
                <label>Select Schedule</label>
                <select name="schedule_id" class="coupon-input" required>
                    <option value="">Select schedule...</option>
                    @foreach($schedules as $sch)
                        <option value="{{ $sch->id }}">
                            {{ $sch->route->departureStation->name }} ➔ {{ $sch->route->arrivalStation->name }}
                            — {{ $sch->departure_time->format('M d, h:i A') }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="input-group">
                <label>Passenger Name</label>
                <input type="text" name="passenger_name" class="coupon-input" placeholder="Full name" required value="{{ old('passenger_name') }}">
            </div>
            <div class="input-group">
                <label>Phone Number</label>
                <input type="text" name="passenger_phone" class="coupon-input" placeholder="01XXXXXXXXX" required value="{{ old('passenger_phone') }}">
            </div>
            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="passenger_email" class="coupon-input" placeholder="email@example.com" required value="{{ old('passenger_email') }}">
            </div>
            <div class="input-group">
                <label>Seat Numbers (comma-separated)</label>
                <input type="text" name="seat_numbers" class="coupon-input" placeholder="A1,A2" required value="{{ old('seat_numbers') }}">
            </div>
            <div class="input-group">
                <label>Total Fare BDT</label>
                <input type="number" name="total_fare" class="coupon-input" placeholder="900" required min="0" step="0.01" value="{{ old('total_fare') }}">
            </div>
            <div class="input-group">
                <label>Payment Method</label>
                <select name="payment_method" class="coupon-input" required>
                    <option value="bKash">bKash</option>
                    <option value="Nagad">Nagad</option>
                    <option value="Card">Card</option>
                    <option value="Cash">Cash</option>
                    <option value="ZiniPay">ZiniPay</option>
                </select>
            </div>
            <div class="input-group">
                <label>Status</label>
                <select name="status" class="coupon-input" required>
                    <option value="PENDING">PENDING</option>
                    <option value="PAID">PAID</option>
                    <option value="SOLD">SOLD</option>
                    <option value="BOOKED">BOOKED</option>
                    <option value="CANCEL_REQUESTED">CANCEL_REQUESTED</option>
                    <option value="CANCELLED">CANCELLED</option>
                </select>
            </div>
            <button class="btn btn-primary" id="booking-form-submit" type="submit" style="height: 42px; margin-top: 10px;">
                Create Booking
            </button>
            <button type="button" class="btn btn-secondary form-cancel-btn" id="booking-form-cancel"
                onclick="resetCrudForm('booking-form', '{{ route('admin.bookings.store') }}', 'Create Booking', 'Create Booking')">
                Cancel Edit
            </button>
        </form>
    </div>

</div>

<script>
    window.BookingsLogs = {
        logsUrl: @json(route('admin.bookings.logs.api')),
        updateRouteTemplate: @json(route('admin.bookings.update', ['id' => '__ID__'])),
        destroyRouteTemplate: @json(route('admin.bookings.destroy', ['id' => '__ID__'])),
        requestCancelRouteTemplate: @json(route('admin.bookings.request-cancel.api', ['id' => '__ID__'])),
    };
</script>
@vite('resources/js/admin/bookings.js')
