/**
 * cancel-requests.js
 *
 * Live-polling log for pending cancellation requests.
 * Polls the API every 5 seconds while the "cancel-requests" tab is open,
 * then pauses when the tab is hidden.
 *
 * Search box: filters server-side by PNR code, phone, e-mail or passenger
 * name. Typing is debounced (350 ms) and Enter fires immediately; the term
 * is re-sent with every poll request so the filter survives auto-refresh.
 *
 * Data contract (set in cancel-requests.blade.php before this file loads):
 *   window.CancelRequests.logsUrl                  — API endpoint returning { cancel_requests: [...] }
 *   window.CancelRequests.approveCancelRouteTemplate — URL template with '__ID__' placeholder
 *
 * Public API (consumed by layout.js):
 *   window.cancelRequestsLogsModule.startPolling()
 *   window.cancelRequestsLogsModule.stopPolling()
 */

import { escapeHtml, formatDateTime, buildUrl } from './utils.js';

(function () {
    const { logsUrl, approveCancelRouteTemplate } = window.CancelRequests;

    const bodyEl     = document.getElementById('cancel-requests-log-body');
    const liveTextEl = document.getElementById('cancel-requests-live-text');
    const searchEl   = document.getElementById('cancel-search');
    const searchClearEl = document.getElementById('cancel-search-clear');
    const csrfToken  = document.querySelector('meta[name="csrf-token"]')?.content || '';

    let pollTimer   = null;
    let isFetching  = false;
    let searchTimer = null;

    /** Current search term (trimmed). */
    function getSearchTerm() {
        return (searchEl?.value || '').trim();
    }

    /** Show the small × button only while the search box has content. */
    function syncSearchClear() {
        if (searchClearEl) searchClearEl.style.display = getSearchTerm() !== '' ? 'block' : 'none';
    }

    /** Update the "live" indicator text next to the panel title. */
    function setLiveText(text) {
        if (!liveTextEl) return;
        liveTextEl.innerHTML = `<span class="live-dot"></span>${text}`;
    }

    // ─── Rendering ────────────────────────────────────────────────────────────

    /** Render all cancellation request rows into the table body. */
    function renderRows(cancelRequests) {
        if (!Array.isArray(cancelRequests) || cancelRequests.length === 0) {
            const term = getSearchTerm();
            const emptyMessage = term
                ? `No cancellation requests match <strong>${escapeHtml(term)}</strong>. Try another PNR code, phone number, e-mail or name.`
                : 'No pending cancellation requests.';

            bodyEl.innerHTML = `
                <tr>
                    <td colspan="9" style="text-align:center; padding:30px; color:var(--text-muted)">
                        ${emptyMessage}
                    </td>
                </tr>`;
            return;
        }

        bodyEl.innerHTML = cancelRequests.map(b => {
            const routeFrom       = b.schedule?.route?.from        || 'N/A';
            const routeTo         = b.schedule?.route?.to          || 'N/A';
            const busName         = b.schedule?.bus?.operator_name || 'N/A';
            const approveCancelUrl = buildUrl(approveCancelRouteTemplate, b.id);

            return `
                <tr>
                    <td style="font-weight:bold; color:var(--primary);">${escapeHtml(b.pnr)}</td>
                    <td style="font-weight:600;">${escapeHtml(b.passenger_name)}</td>
                    <td>
                        <div>${escapeHtml(b.passenger_phone)}</div>
                        <div style="font-size:11px; color:var(--text-secondary)">${escapeHtml(b.passenger_email)}</div>
                    </td>
                    <td>
                        <div>${escapeHtml(routeFrom)} ➔ ${escapeHtml(routeTo)}</div>
                        <div style="font-size:11px; color:var(--text-secondary)">
                            ${escapeHtml(formatDateTime(b.schedule?.departure_time))}
                        </div>
                    </td>
                    <td>${escapeHtml(busName)}</td>
                    <td style="font-weight:bold;">${escapeHtml(b.seat_numbers)}</td>
                    <td style="color:var(--gold); font-weight:bold;">BDT ${Number(b.total_fare || 0).toLocaleString()}</td>
                    <td style="font-size:12px; color:var(--text-secondary);">${escapeHtml(formatDateTime(b.updated_at))}</td>
                    <td>
                        <form action="${escapeHtml(approveCancelUrl)}" method="POST"
                              onsubmit="return confirm('Approve this cancellation request?');">
                            <input type="hidden" name="_token" value="${escapeHtml(csrfToken)}">
                            <button class="btn btn-danger btn-sm" type="submit">Approve Cancel</button>
                        </form>
                    </td>
                </tr>`;
        }).join('');
    }

    // ─── Data fetching ────────────────────────────────────────────────────────

    /** Build query params from the search box and the date filter inputs. */
    function getFilters() {
        const params = new URLSearchParams();
        const period = document.getElementById('cancel-period')?.value || 'all';
        params.set('period', period);
        if (period === 'custom') {
            params.set('from_date', document.getElementById('cancel-from-date')?.value || '');
            params.set('to_date', document.getElementById('cancel-to-date')?.value || '');
        }

        const search = getSearchTerm();
        if (search !== '') params.set('search', search);

        return params;
    }

    /**
     * Fetch the latest cancellation requests from the API and re-render the table.
     * @param {boolean} silent — when true, suppresses the "update failed" text on error
     */
    async function fetchLogs(silent = false) {
        if (!bodyEl || isFetching) return;
        isFetching = true;

        try {
            const params = getFilters();
            const url = params.toString() ? `${logsUrl}?${params}` : logsUrl;
            const res = await fetch(url, { headers: { Accept: 'application/json' } });
            if (!res.ok) return;

            const data = await res.json();
            renderRows(data.cancel_requests || []);

            const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            setLiveText(`Live — last updated ${time} (refreshes every 5s)`);
        } catch {
            if (!silent) setLiveText('Live update failed');
        } finally {
            isFetching = false;
        }
    }

    // ─── Polling control ──────────────────────────────────────────────────────

    function startPolling() {
        stopPolling();
        fetchLogs();
        pollTimer = setInterval(() => fetchLogs(true), 5_000);
    }

    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
        setLiveText('Live paused');
    }

    // ─── Date filter wiring ──────────────────────────────────────────────────
    document.getElementById('cancel-period')?.addEventListener('change', () => {
        const period = document.getElementById('cancel-period')?.value;
        const customEl = document.getElementById('cancel-custom-dates');
        if (customEl) customEl.style.display = period === 'custom' ? 'flex' : 'none';
    });

    document.getElementById('cancel-apply-filter')?.addEventListener('click', () => {
        const period = document.getElementById('cancel-period')?.value;
        if (period === 'custom') {
            const from = document.getElementById('cancel-from-date')?.value;
            const to = document.getElementById('cancel-to-date')?.value;
            if (!from || !to) {
                alert('Please select both From and To dates for custom range.');
                return;
            }
        }
        fetchLogs();
    });

    // ─── Search box wiring ───────────────────────────────────────────────────
    searchEl?.addEventListener('input', () => {
        syncSearchClear();
        clearTimeout(searchTimer);
        // Debounce so a full PNR / phone number is typed before querying
        searchTimer = setTimeout(() => fetchLogs(), 350);
    });

    searchEl?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearTimeout(searchTimer);
            fetchLogs();
        } else if (e.key === 'Escape') {
            e.preventDefault();
            searchEl.value = '';
            syncSearchClear();
            fetchLogs();
        }
    });

    searchClearEl?.addEventListener('click', () => {
        if (searchEl) searchEl.value = '';
        syncSearchClear();
        searchEl?.focus();
        fetchLogs();
    });

    // ─── Reset button: clears search + date range ────────────────────────────
    document.getElementById('cancel-reset-filter')?.addEventListener('click', () => {
        if (searchEl) searchEl.value = '';
        syncSearchClear();

        const periodEl = document.getElementById('cancel-period');
        if (periodEl) periodEl.value = 'all';

        const customEl = document.getElementById('cancel-custom-dates');
        if (customEl) customEl.style.display = 'none';

        const fromEl = document.getElementById('cancel-from-date');
        const toEl   = document.getElementById('cancel-to-date');
        if (fromEl) fromEl.value = '';
        if (toEl) toEl.value = '';

        fetchLogs();
    });

    syncSearchClear();

    window.cancelRequestsLogsModule = { startPolling, stopPolling };

    // Auto-fetch if cancel-requests tab is currently displayed
    const tabEl = document.getElementById('tab-content-cancel-requests');
    if (window.location.hash === '#cancel-requests' || (tabEl && tabEl.style.display !== 'none')) {
        startPolling();
    }
})();
