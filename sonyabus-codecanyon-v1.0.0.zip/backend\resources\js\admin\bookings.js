/**
 * bookings.js
 *
 * Live-polling log for all booking records, plus the inline edit form.
 * Polls the API every 5 seconds while the "bookings" tab is open,
 * then pauses when the tab is hidden.
 *
 * Search box: filters server-side by PNR code, phone, e-mail or passenger
 * name. Typing is debounced (350 ms) and Enter fires immediately; the term
 * is re-sent with every poll request so the filter survives auto-refresh.
 *
 * Data contract (set in bookings.blade.php before this file loads):
 *   window.BookingsLogs.logsUrl                    — API endpoint returning { bookings: [...] }
 *   window.BookingsLogs.updateRouteTemplate         — URL template with '__ID__' placeholder
 *   window.BookingsLogs.destroyRouteTemplate        — URL template with '__ID__' placeholder
 *   window.BookingsLogs.requestCancelRouteTemplate  — URL template with '__ID__' placeholder
 *
 * Public API (consumed by layout.js):
 *   window.bookingsLogsModule.startPolling()
 *   window.bookingsLogsModule.stopPolling()
 *
 * Public API (called from rendered row buttons):
 *   window.editBookingFromLog(bookingId)
 */
import { escapeHtml, formatDateTime, buildUrl, statusBadgeClass } from './utils.js';

(function () {
    const { logsUrl, updateRouteTemplate, destroyRouteTemplate, requestCancelRouteTemplate } = window.BookingsLogs;

    const bodyEl     = document.getElementById('bookings-log-body');
    const liveTextEl = document.getElementById('bookings-live-text');
    const searchEl   = document.getElementById('bookings-search');
    const searchClearEl = document.getElementById('bookings-search-clear');
    const csrfToken  = document.querySelector('meta[name="csrf-token"]')?.content || '';

    let pollTimer   = null;
    let isFetching  = false;
    let searchTimer = null;
    // Keyed by booking ID so edit buttons can look up the full record without re-fetching
    let bookingsMap = {};
    let allBookings = [];
    let currentPage = 1;
    let perPage = 10;

    /** Current search term (trimmed). */
    function getSearchTerm() {
        return (searchEl?.value || '').trim();
    }

    /** Show the small × button only while the search box has content. */
    function syncSearchClear() {
        if (searchClearEl) searchClearEl.style.display = getSearchTerm() !== '' ? 'block' : 'none';
    }

    /** Update the "live" indicator text next to the panel title. */
    function setLiveText(text) {
        if (!liveTextEl) return;
        liveTextEl.innerHTML = `<span class="live-dot"></span>${text}`;
    }

    // ─── Rendering ────────────────────────────────────────────────────────────

    /** Render all booking rows into the table body and re-bind edit buttons. */
    function renderRows(bookings) {
        bookingsMap = {};

        if (!Array.isArray(bookings) || bookings.length === 0) {
            const term = getSearchTerm();
            const emptyMessage = term
                ? `No bookings match <strong>${escapeHtml(term)}</strong>. Try another PNR code, phone number, e-mail or name.`
                : 'No reservation records found.';

            bodyEl.innerHTML = `
                <tr>
                    <td colspan="9" style="text-align:center; padding:30px; color:var(--text-muted)">
                        ${emptyMessage}
                    </td>
                </tr>`;
            return;
        }

        bodyEl.innerHTML = bookings.map(b => {
            bookingsMap[b.id] = b;

            const routeFrom  = b.schedule?.route?.from        || 'N/A';
            const routeTo    = b.schedule?.route?.to          || 'N/A';
            const busName    = b.schedule?.bus?.operator_name || 'N/A';
            const coachRegNo = b.schedule?.bus?.coach_number || 'N/A';
            const updateUrl  = buildUrl(updateRouteTemplate,  b.id);
            const destroyUrl = buildUrl(destroyRouteTemplate, b.id);

            // Only show the ZiniPay "Pay" button for pending ZiniPay bookings
            const isZinipayPending = b.status === 'PENDING' && (b.payment_method || '').toLowerCase() === 'zinipay';
            const payButton = isZinipayPending
                ? `<a href="/admin/bookings/${b.id}/pay" class="btn btn-primary btn-sm"
                       style="display:inline-flex; align-items:center; justify-content:center;
                              height:28px; padding:0 10px; text-decoration:none;
                              font-size:12px; font-weight:600;">
                       Pay
                   </a>`
                : '';

            // Show the Cancel button for any status that isn't already cancelled/requested
            const isCancellable = !['CANCELLED', 'CANCEL_REQUESTED'].includes(b.status);
            const cancelUrl = buildUrl(requestCancelRouteTemplate, b.id);
            const cancelButton = isCancellable
                ? `<button type="button" class="btn btn-sm request-cancel-btn"
                           data-booking-id="${b.id}"
                           data-cancel-url="${escapeHtml(cancelUrl)}"
                           style="background-color:rgba(245,158,11,0.15);color:#FBBF24;
                                  border:1px solid rgba(245,158,11,0.3);">
                       Cancel
                   </button>`
                : '';

            return `
                <tr>
                    <td style="font-weight:bold; color:var(--primary);">${escapeHtml(b.pnr)}</td>
                    <td style="font-weight:600;">${escapeHtml(b.passenger_name)}</td>
                    <td>
                        <div>${escapeHtml(b.passenger_phone)}</div>
                        <div style="font-size:11px; color:var(--text-secondary)">${escapeHtml(b.passenger_email)}</div>
                    </td>
                    <td>
                        <div>${escapeHtml(routeFrom)} ➔ ${escapeHtml(routeTo)}</div>
                        <div style="font-size:11px; color:var(--text-secondary)">Bus: ${escapeHtml(busName)}</div>
                        <div style="font-size:11px; color:var(--text-secondary)">
                            ${escapeHtml(formatDateTime(b.schedule?.departure_time))}
                        </div>
                    </td>
                    <td style="font-weight:600; color:var(--text-secondary);">${escapeHtml(coachRegNo)}</td>
                    <td style="font-weight:bold;">${escapeHtml(b.seat_numbers)}</td>
                    <td style="color:var(--gold); font-weight:bold;">BDT ${Number(b.total_fare || 0).toLocaleString()}</td>
                    <td><span class="badge-status ${statusBadgeClass(b.status)}">${escapeHtml(b.status)}</span></td>
                    <td>
                        <div class="action-btns">
                            ${payButton}
                            <button type="button" class="btn btn-secondary btn-sm edit-booking-btn"
                                    data-booking-id="${b.id}">
                                Edit
                            </button>
                            ${cancelButton}
                            <form action="${escapeHtml(destroyUrl)}" method="POST"
                                  onsubmit="return confirm('Permanently delete this booking record?');"
                                  style="display:inline-block;">
                                <input type="hidden" name="_token"  value="${escapeHtml(csrfToken)}">
                                <input type="hidden" name="_method" value="DELETE">
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>`;
        }).join('');

        bindEditButtons();
        bindCancelButtons();
    }

    /** Render the pagination bar and the rows for the current page. */
    function renderPagination() {
        const total = allBookings.length;
        const totalPages = Math.max(1, Math.ceil(total / perPage));
        if (currentPage > totalPages) currentPage = totalPages;
        const start = total === 0 ? 0 : (currentPage - 1) * perPage + 1;
        const end = Math.min(currentPage * perPage, total);

        const infoEl = document.getElementById('bookings-page-info');
        const prevEl = document.getElementById('bookings-prev-page');
        const nextEl = document.getElementById('bookings-next-page');

        if (infoEl) infoEl.textContent = `Showing ${start}–${end} of ${total}`;
        if (prevEl) prevEl.disabled = currentPage <= 1;
        if (nextEl) nextEl.disabled = currentPage >= totalPages;

        const slice = allBookings.slice((currentPage - 1) * perPage, currentPage * perPage);
        renderRows(slice);
    }

    /** Attach click listeners to all "Edit" buttons after a re-render. */
    function bindEditButtons() {
        document.querySelectorAll('.edit-booking-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.dataset.bookingId, 10);
                if (!Number.isNaN(id)) window.editBookingFromLog(id);
            });
        });
    }

    /** Attach click listeners to all "Cancel" buttons after a re-render. */
    function bindCancelButtons() {
        document.querySelectorAll('.request-cancel-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id  = btn.dataset.bookingId;
                const url = btn.dataset.cancelUrl;
                if (!confirm(`Submit a cancellation request for booking #${id}? It will appear in Cancel Requests for approval.`)) return;

                btn.disabled = true;
                btn.textContent = '...';

                try {
                    const res = await fetch(url, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': csrfToken,
                            'Accept': 'application/json',
                        },
                    });

                    const data = await res.json();

                    if (res.ok) {
                        // Refresh the table to reflect the new status
                        fetchLogs();
                    } else {
                        alert(data.message || 'Failed to submit cancellation request.');
                        btn.disabled = false;
                        btn.textContent = 'Cancel';
                    }
                } catch {
                    alert('Network error. Please try again.');
                    btn.disabled = false;
                    btn.textContent = 'Cancel';
                }
            });
        });
    }

    // ─── Edit form ────────────────────────────────────────────────────────────

    /**
     * Populate the booking form with an existing booking's data for editing.
     * Relies on setCrudFormMode() from layout.js.
     */
    window.editBookingFromLog = function (bookingId) {
        const booking = bookingsMap[bookingId];
        if (!booking) return;

        setCrudFormMode('booking-form', {
            mode:        'edit',
            id:          booking.id,
            action:      buildUrl(updateRouteTemplate, booking.id),
            title:       `Edit Booking ${booking.pnr}`,
            submitLabel: 'Update Booking',
            fields: {
                passenger_name:  booking.passenger_name,
                passenger_phone: booking.passenger_phone,
                passenger_email: booking.passenger_email,
                seat_numbers:    booking.seat_numbers,
                total_fare:      booking.total_fare,
                status:          booking.status,
                payment_method:  booking.payment_method || 'bKash',
            },
        });
    };

    // ─── Data fetching ────────────────────────────────────────────────────────

    /** Build query params from the search box and the date filter inputs. */
    function getFilters() {
        const params = new URLSearchParams();
        const period = document.getElementById('bookings-period')?.value || 'all';
        params.set('period', period);
        if (period === 'custom') {
            params.set('from_date', document.getElementById('bookings-from-date')?.value || '');
            params.set('to_date', document.getElementById('bookings-to-date')?.value || '');
        }

        const search = getSearchTerm();
        if (search !== '') params.set('search', search);

        return params;
    }

    /**
     * Fetch the latest bookings from the API and re-render the table.
     * @param {boolean} silent — when true, suppresses the "update failed" text on error
     */
    async function fetchLogs(silent = false) {
        if (!bodyEl || isFetching) return;
        isFetching = true;

        try {
            const params = getFilters();
            const url = params.toString() ? `${logsUrl}?${params}` : logsUrl;
            const res = await fetch(url, { headers: { Accept: 'application/json' } });
            if (!res.ok) return;

            const data = await res.json();
            allBookings = data.bookings || [];
            currentPage = 1;
            renderPagination();

            const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            setLiveText(`Live — last updated ${time} (refreshes every 5s)`);
        } catch {
            if (!silent) setLiveText('Live update failed');
        } finally {
            isFetching = false;
        }
    }

    // ─── Polling control ──────────────────────────────────────────────────────

    function startPolling() {
        stopPolling();
        fetchLogs();
        pollTimer = setInterval(() => fetchLogs(true), 5_000);
    }

    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
        setLiveText('Live paused');
    }

    // ─── Date filter wiring ──────────────────────────────────────────────────
    document.getElementById('bookings-period')?.addEventListener('change', () => {
        const period = document.getElementById('bookings-period')?.value;
        const customEl = document.getElementById('bookings-custom-dates');
        if (customEl) customEl.style.display = period === 'custom' ? 'flex' : 'none';
    });

    document.getElementById('bookings-apply-filter')?.addEventListener('click', () => {
        const period = document.getElementById('bookings-period')?.value;
        if (period === 'custom') {
            const from = document.getElementById('bookings-from-date')?.value;
            const to = document.getElementById('bookings-to-date')?.value;
            if (!from || !to) {
                alert('Please select both From and To dates for custom range.');
                return;
            }
        }
        fetchLogs();
    });

    // ─── Search box wiring ───────────────────────────────────────────────────
    searchEl?.addEventListener('input', () => {
        syncSearchClear();
        clearTimeout(searchTimer);
        // Debounce so a full PNR / phone number is typed before querying
        searchTimer = setTimeout(() => fetchLogs(), 350);
    });

    searchEl?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearTimeout(searchTimer);
            fetchLogs();
        } else if (e.key === 'Escape') {
            e.preventDefault();
            searchEl.value = '';
            syncSearchClear();
            fetchLogs();
        }
    });

    searchClearEl?.addEventListener('click', () => {
        if (searchEl) searchEl.value = '';
        syncSearchClear();
        searchEl?.focus();
        fetchLogs();
    });

    // ─── Reset button: clears search + date range ────────────────────────────
    document.getElementById('bookings-reset-filter')?.addEventListener('click', () => {
        if (searchEl) searchEl.value = '';
        syncSearchClear();

        const periodEl = document.getElementById('bookings-period');
        if (periodEl) periodEl.value = 'all';

        const customEl = document.getElementById('bookings-custom-dates');
        if (customEl) customEl.style.display = 'none';

        const fromEl = document.getElementById('bookings-from-date');
        const toEl   = document.getElementById('bookings-to-date');
        if (fromEl) fromEl.value = '';
        if (toEl) toEl.value = '';

        fetchLogs();
    });

    syncSearchClear();

    // ─── Pagination wiring ────────────────────────────────────────────────────
    document.getElementById('bookings-per-page')?.addEventListener('change', (e) => {
        perPage = parseInt(e.target.value, 10) || 10;
        currentPage = 1;
        renderPagination();
    });

    document.getElementById('bookings-prev-page')?.addEventListener('click', () => {
        if (currentPage > 1) { currentPage--; renderPagination(); }
    });

    document.getElementById('bookings-next-page')?.addEventListener('click', () => {
        const totalPages = Math.max(1, Math.ceil(allBookings.length / perPage));
        if (currentPage < totalPages) { currentPage++; renderPagination(); }
    });

    window.bookingsLogsModule = { startPolling, stopPolling };

    const paymentSelect = document.querySelector('#booking-form select[name="payment_method"]');
    const statusSelect = document.querySelector('#booking-form select[name="status"]');
    if (paymentSelect && statusSelect) {
        paymentSelect.addEventListener('change', () => {
            if (String(paymentSelect.value).toLowerCase() === 'cash') {
                statusSelect.value = 'SOLD';
            }
        });
    }

    // Auto-fetch if bookings tab is currently displayed
    const tabEl = document.getElementById('tab-content-bookings');
    if (window.location.hash === '#bookings' || (tabEl && tabEl.style.display !== 'none')) {
        startPolling();
    }
})();
